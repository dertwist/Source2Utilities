import bpy
from bpy.app.handlers import persistent
from bpy.props import FloatProperty, BoolProperty, StringProperty
import math

# Unified properties for all axes

bpy.types.Scene.rotation_step = FloatProperty(
    name="Rotation Step",
    default=45.0,
    min=1.0,
    max=360.0,
    description="Set the rotation step for all axes in degrees"
)

bpy.types.Scene.rotation_enabled = BoolProperty(
    name="Enable Rotation Limit",
    default=False,
    description="Enable or disable rotation limit for rotations"
)

bpy.types.Scene.location_step = FloatProperty(
    name="Location Step",
    default=100.0,
    min=1.0,
    max=10000.0,
    description="Set the location step for all axes"
)

bpy.types.Scene.location_enabled = BoolProperty(
    name="Enable Location Limit",
    default=False,
    description="Enable or disable location limit for location"
)

def transformEvent(obj, scene):
    # Apply unified rotation limit if enabled
    if scene.rotation_enabled:
        # Convert step from degrees to radians once
        step_rad = math.radians(scene.rotation_step)
        for i in range(3):
            limited_rotation = round(obj.rotation_euler[i] / step_rad) * step_rad
            obj.rotation_euler[i] = limited_rotation

    # Apply unified location limit if enabled
    if scene.location_enabled:
        # Here we assume a scale adjustment as originally divided by 100
        step = scene.location_step / 100
        for i in range(3):
            limited_location = round(obj.location[i] / step) * step
            obj.location[i] = limited_location

@persistent
def on_depsgraph_update(scene):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for update in depsgraph.updates:
        if update.is_updated_transform:
            obj = bpy.context.active_object
            if obj is not None:
                transformEvent(obj, scene)

# UI functions for unified properties

def draw_menu(self, context):
    layout = self.layout
    scene = context.scene

    col = layout.column(align=True)
    col.label(text="Rotation")
    col.prop(scene, "rotation_enabled", text="Enable Rotation Limit")
    row = col.row(align=True)
    row.operator("object.submenu_button", text="Common").prm = "rot"
    row.prop(scene, "rotation_step", text="Step")

    col.separator()

    col.label(text="Location")
    col.prop(scene, "location_enabled", text="Enable Location Limit")
    row = col.row(align=True)
    row.operator("object.submenu_button", text="Common").prm = "loc"
    row.prop(scene, "location_step", text="Step")

def draw_popup(self, context):
    global menu_type
    col = self.layout.column()
    if menu_type == "rot":
        for val in [5, 10, 15, 30, 45, 60, 90, 120]:
            op = col.operator("object.step_preset_set", text=str(val))
            op.value = float(val)
            op.prm = "rot"
    elif menu_type == "loc":
        for val in [1, 5, 10, 50, 100, 500, 1000, 5000, 10000]:
            op = col.operator("object.step_preset_set", text=str(val))
            op.value = float(val)
            op.prm = "loc"

class submenu_button(bpy.types.Operator):
    bl_idname = "object.submenu_button"
    bl_label = "Show presets menu"
    prm: StringProperty()

    def execute(self, context):
        global menu_type
        menu_type = self.prm
        if menu_type == "rot":
            context.window_manager.popup_menu(draw_popup, title="Select rotation step")
        elif menu_type == "loc":
            context.window_manager.popup_menu(draw_popup, title="Select location step")
        return {'FINISHED'}

class step_preset_set(bpy.types.Operator):
    bl_idname = "object.step_preset_set"
    bl_label = "Set Step Value"
    bl_options = {'REGISTER', 'UNDO'}
    value: FloatProperty()
    prm: StringProperty()

    def execute(self, context):
        if self.prm == "rot":
            context.scene.rotation_step = self.value
        elif self.prm == "loc":
            context.scene.location_step = self.value
        return {'FINISHED'}

# Panel definition placed under the "other" category in the main addon
class TransformStepsPanel(bpy.types.Panel):
    bl_label = "Transform By Steps"
    bl_idname = "OBJECT_PT_steps"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "other"

    def draw(self, context):
        draw_menu(self, context)

# List of classes for registration in this module
classes = [
    TransformStepsPanel,
    submenu_button,
    step_preset_set
]

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    if on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_depsgraph_update)

def unregister():
    from bpy.utils import unregister_class
    if on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph_update)
    for cls in reversed(classes):
        unregister_class(cls)

if __name__ == "__main__":
    register()